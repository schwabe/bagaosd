float pitchgain=12.0;
float rollgain=7.6;

bool invertpitch=false;
bool invertroll=false;

//Flight mode
int flightmode=5;               //2=Alt Hold(Attitude), 1=Acrobatic, 6=Return to launch(Failsafe), 5=Loiter(GPS Attitude);

//Gimbal position 
float pitch_rad=10;
float roll_rad=10;
long levelpitch=0;
long levelroll=0;
long pitch=1500;
long roll=1500;

float capacity=0;
float mahout=0;

//Other sensors
int receiver_rssi=0;
int throttlepercent=0;



